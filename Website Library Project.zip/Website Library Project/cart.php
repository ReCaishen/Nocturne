<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bookstore";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch wishlist items
$sql = "SELECT * FROM wishlist ORDER BY date_added DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wishlist - La Cité du Savoir</title>
    <link rel="stylesheet" type="text/css" href="Assets/Css/Style.css">
    <link rel="icon" href="Assets/Img/Logo.jpg">
</head>
<body>
    <!-- Navigation (copy from your index.php) -->
    <nav class="Navigation-Top">
        <div class="Navigation-Container">
            <div class="Hamburger-Menu">
                <div class="Hamburger-Icon" onclick="toggleMenu()">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
            <div class="Navigation-Links" id="navigationLinks">
                <button class="Back-Button" onclick="toggleMenu()"><ion-icon name="close-sharp"></ion-icon></button>
                <ul>
                    <li>
                        <a class="Active" href="Index.php"> Home </a>
                    </li>
                    <li>
                        <a href="About.php"> About </a>
                    </li>
                    <li>
                        <a href="#News"> Product </a>
                    </li>
                </ul>
            </div>
            <div class="Website-Logo">
                <div class="Logo-Image">
                    <a>
                        <img src="Assets/Img/Logo.jpg">
                    </a>
                </div>
                <div class="Website-Name">
                    <a>
                        <p> La Cité du Savoir </p>
                    </a>
                </div>
            </div>
            <div class="Navigation-Links-2">
                <ul>
                    <li>
                        <a href="cart.php">
                            <ion-icon name="cart-outline"></ion-icon>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="Card-Card">
        <div class="Card-Container">
            <div class="Card-Block-Container">
                <div class="Block-Container-Display">
                    <div class="Shoot">
                        <div class="Availability-Tag">
                            <p>Your Wishlist</p>
                            <div class="Search-Input">
                                <input type="search" placeholder="Search Here"><ion-icon name="search-outline"></ion-icon>
                            </div>
                        </div>
                        <div class="Content-Card-Display-1">
                            <?php
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    echo '<div class="Display-Card" data-title="' . $row["book_title"] . '" data-author="' . $row["author"] . '" data-img="' . $row["img_src"] . '" data-desc="' . $row["description"] . '">';
                                    echo '<a>';
                                    echo '<img src="' . $row["img_src"] . '">';
                                    echo '<p style="font-weight: bolder; text-transform: uppercase; padding: 20px 0 0;">' . $row["book_title"] . '<br><span style="color: rgb(100 100 100); font-weight: normal; text-transform: none; font-size: 14px;">' . $row["author"] . '</span></p>';
                                    echo '<p style="padding: 20px 0 0;">Added on: ' . $row["date_added"] . '</p>';
                                    echo '</a>';
                                    echo '</div>';
                                }
                            } else {
                                echo "<p>Your wishlist is empty.</p>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer (copy from your index.php) -->
    <footer class="Footer">
        <!-- ... (paste your footer HTML here) ... -->
    </footer>

    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

    <script>
        function toggleMenu() {
            var navigationLinks = document.getElementById("navigationLinks");
            if (navigationLinks.classList.contains('active')) {
                navigationLinks.classList.remove('active');
            } else {
                navigationLinks.classList.add('active');
            }
        }
    
        window.addEventListener('scroll', function() {
            var navigationLinks = document.getElementById("navigationLinks");
            if (navigationLinks.classList.contains('active')) {
                navigationLinks.classList.add('scrolling');
            }
        });
    </script>

    <script>
        document.querySelectorAll('.Display-Card').forEach(card => {
            card.addEventListener('click', function(event) {
                event.preventDefault();
                const imgSrc = card.getAttribute('data-img');
                const bookTitle = card.getAttribute('data-title');
                const author = card.getAttribute('data-author');
                const desc = card.getAttribute('data-desc');

                document.getElementById('modal-img').src = imgSrc;
                document.getElementById('modal-title').innerText = bookTitle;
                document.getElementById('modal-author').innerText = author;
                document.getElementById('modal-desc').innerText = desc;

                document.getElementById('modal').style.display = 'block';
            });
        });

        window.addEventListener('click', function(event) {
            if (event.target == document.getElementById('modal')) {
                document.getElementById('modal').style.display = 'none';
            }
        });
    </script>

    <script>
        function addToWishlist() {
            const title = document.getElementById('modal-title').innerText;
            const author = document.getElementById('modal-author').innerText;
            const imgSrc = document.getElementById('modal-img').src;
            const description = document.getElementById('modal-desc').innerText;

            console.log("Sending data:", { title, author, imgSrc, description });

            const data = new FormData();
            data.append('title', title);
            data.append('author', author);
            data.append('imgSrc', imgSrc);
            data.append('description', description);

            fetch('add_to_wishlist.php', {
                method: 'POST',
                body: data
            })
            .then(response => response.text())
            .then(result => {
                console.log('Server response:', result);
                alert('Added to wishlist!');
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to add to wishlist');
            });
        }
    </script>
</body>
</html>

<?php
$conn->close();
?>