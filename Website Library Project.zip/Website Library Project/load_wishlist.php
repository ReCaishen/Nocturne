<?php
// Koneksi ke database
$servername = "localhost"; // Ganti sesuai dengan server Anda
$username = "root"; // Ganti dengan username PHPMyAdmin Anda
$password = ""; // Ganti dengan password PHPMyAdmin Anda
$dbname = "bookstore"; // Ganti dengan nama database Anda

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query untuk mengambil semua data dari tabel cart
$sql = "SELECT * FROM cart";
$result = $conn->query($sql);

$wishlistItems = array();

if ($result->num_rows > 0) {
    // Mengambil data dari setiap baris hasil query
    while($row = $result->fetch_assoc()) {
        $wishlistItems[] = array(
            'id' => $row['id'],
            'title' => $row['title'],
            'author' => $row['author'],
            'img' => $row['img'],
            'desc' => $row['desc']
        );
    }
}

// Mengembalikan hasil dalam format JSON
echo json_encode($wishlistItems);

$conn->close();
?>

<?php
// File: load_wishlist.php
include 'config.php'; // Include file config.php untuk koneksi database

// Query untuk mengambil semua data dari tabel cart
$sql = "SELECT * FROM cart";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $rows = array();
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    echo json_encode($rows); // Mengembalikan data dalam format JSON
} else {
    echo "0 results";
}
$conn->close();
?>
