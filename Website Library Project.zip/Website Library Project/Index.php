<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <title> La Cité du Savoir </title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='Assets/Css/Style.css'>
    <link rel='icon' href='Assets/Img/Logo.jpg'>
</head>
<body>
    
    <!--Navigation-->
    
    <nav class="Navigation-Top">
        <div class="Navigation-Container">
            <div class="Hamburger-Menu">
                <div class="Hamburger-Icon" onclick="toggleMenu()">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
            <div class="Navigation-Links" id="navigationLinks">
                <button class="Back-Button" onclick="toggleMenu()"><ion-icon name="close-sharp"></ion-icon></button>
                <ul>
                    <li>
                        <a class="Active" href="Index.php"> Home </a>
                    </li>
                    <li>
                        <a href="About.html"> About </a>
                    </li>
                    <li>
                        <a href="#Product"> Product </a>
                    </li>
                </ul>
            </div>
            <div class="Website-Logo">
                <div class="Logo-Image">
                    <a>
                        <img src="Assets/Img/Logo.jpg">
                    </a>
                </div>
                <div class="Website-Name">
                    <a>
                        <p> La Cité du Savoir </p>
                    </a>
                </div>
            </div>
            <div class="Navigation-Links-2">
                <ul>
                    <li>
                        <a href="cart.php">
                            <ion-icon name="cart-outline"></ion-icon>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!--End Of Navigation-->

    <!--Content-->

    <section class="Card-Card">
        <div class="Card-Container">
            <div class="Image-Card">
                <img src="https://img.money.com/2019/05/librarythings_1.jpg">
                <div class="Text-Welcoming">
                    <div class="Text-Centered-A">
                        <a href=""> La Cité du Savoir </a>
                    </div>
                    <div class="Text-Centered-P">
                        <p> The World Of Knowledge <br> The World Better With </p>
                    </div>
                    <div class="">
                        <p> Where Magic 'Lies' Within </p>
                    </div>
                </div>
            </div>
            <div class="Text-Texting">
                <p> What's News </p>
            </div>
            <div class="Content-Card-Display">
                <div class="Display-Card">
                    <a href="">
                        <img src="Assets/Img/Book 7.jpg" style="height: 300px; object-fit: contain;">
                        <p style="font-weight: bolder; text-transform: uppercase; padding: 20px 0 0;"> The Princess Spy <br> <span style="color: rgb(100 100 100); font-weight: normal; text-transform: none; font-size: 14px;"> Larry Loftis </span> </p>
                        <p style="padding: 20px 0 0;"> Learn More </p>
                    </a>
                </div>
                <div class="Display-Card">
                    <a href="">
                        <img src="Assets/Img/Book 8.jpg" style="height: 300px; object-fit: contain;">
                        <p style="font-weight: bolder; text-transform: uppercase; padding: 20px 0 0;"> Catalina A Novel <br> <span style="color: rgb(100 100 100); font-weight: normal; text-transform: none; font-size: 14px;"> Karla Cornejo </span> </p>
                        <p style="padding: 20px 0 0;"> Learn More </p>
                    </a>
                </div>
                <div class="Display-Card">
                    <a href="">
                        <img src="Assets/Img/Book 9.jpg" style="height: 300px; object-fit: contain;">
                        <p style="font-weight: bolder; text-transform: uppercase; padding: 20px 0 0;"> Liars : A Novel <br> <span style="color: rgb(100 100 100); font-weight: normal; text-transform: none; font-size: 14px;"> Sarah Manguso </span> </p>
                        <p style="padding: 20px 0 0;"> Learn More </p>
                    </a>
                </div>
            </div>
            <div class="Contamination">
                <div class="Knowledge-Card">
                    <p> "The Knowledge With In" </p>
                </div>
                <div class="Join-Tag">
                    <a href=""> Join </a>
                </div>
            </div>
            <div class="Card-Block-Container">
                <div class="Block-Container-Display">
                    <div class="Shoot">
                        <div class="Availability-Tag" id="Product">
                            <p> Product </p>
                            <div class="Search-Input">
                                <input type="search" placeholder="Search Here"><ion-icon name="search-outline"></ion-icon>
                            </div>
                        </div>
                        <div class="Content-Card-Display-1">
                            <div class="Display-Card" data-title="The First Conspiracy" data-author="Brad Meltzer" data-img="Assets/Img/Book 1.jpg" data-desc="A gripping account of a secret plot to kill George Washington.">
                                <a href="#">
                                    <img src="Assets/Img/Book 1.jpg">
                                    <p style="font-weight: bolder; text-transform: uppercase; padding: 20px 0;">The First Conspiracy<br><span style="color: rgb(100 100 100); font-weight: normal; font-size: 14px;">Brad Meltzer</span></p>
                                    <p style="padding: 20px 0;">Learn More</p>
                                </a>
                            </div>
                            <div class="Display-Card" data-title="Benjamin Franklin" data-author="Walter Isaacson" data-img="Assets/Img/Book 2.jpg" data-desc="A comprehensive biography of Benjamin Franklin.">
                                <a href="#">
                                    <img src="Assets/Img/Book 2.jpg">
                                    <p style="font-weight: bolder; text-transform: uppercase; padding: 20px 0;">Benjamin Franklin<br><span style="color: rgb(100 100 100); font-weight: normal; font-size: 14px;">Walter Isaacson</span></p>
                                    <p style="padding: 20px 0;">Learn More</p>
                                </a>
                            </div>
                            <div class="Display-Card" data-title="1776" data-author="David McCullough" data-img="Assets/Img/Book 3.jpg" data-desc="An in-depth narrative of the American Revolutionary War.">
                                <a href="#">
                                    <img src="Assets/Img/Book 3.jpg">
                                    <p style="font-weight: bolder; text-transform: uppercase; padding: 20px 0;">1776<br><span style="color: rgb(100 100 100); font-weight: normal; font-size: 14px;">David McCullough</span></p>
                                    <p style="padding: 20px 0;">Learn More</p>
                                </a>
                            </div>
                            <div class="Display-Card" data-title="History Of The United States" data-author="Howard Zinn" data-img="Assets/Img/Book 4.jpg" data-desc="A critical perspective on the history of the United States.">
                                <a href="#">
                                    <img src="Assets/Img/Book 4.jpg">
                                    <p style="font-weight: bolder; text-transform: uppercase; padding: 20px 0;">History Of The United States<br><span style="color: rgb(100 100 100); font-weight: normal; font-size: 14px;">Howard Zinn</span></p>
                                    <p style="padding: 20px 0;">Learn More</p>
                                </a>
                            </div>
                            <div class="Display-Card" data-title="The Greatest Beer Run Ever" data-author="John Dondhue" data-img="Assets/Img/Book 5.jpg" data-desc="A humorous yet poignant tale of a man's mission during the Vietnam War.">
                                <a href="#">
                                    <img src="Assets/Img/Book 5.jpg">
                                    <p style="font-weight: bolder; text-transform: uppercase; padding: 20px 0;">The Greatest Beer Run Ever<br><span style="color: rgb(100 100 100); font-weight: normal; font-size: 14px;">John Dondhue</span></p>
                                    <p style="padding: 20px 0;">Learn More</p>
                                </a>
                            </div>
                            <div class="Display-Card" data-title="Black Flags, Blue Waters" data-author="Eric Jay Dolin" data-img="Assets/Img/Book 6.jpg" data-desc="A gripping history of piracy in the Caribbean.">
                                <a href="#">
                                    <img src="Assets/Img/Book 6.jpg">
                                    <p style="font-weight: bolder; text-transform: uppercase; padding: 20px 0;">Black Flags, Blue Waters<br><span style="color: rgb(100 100 100); font-weight: normal; font-size: 14px;">Eric Jay Dolin</span></p>
                                    <p style="padding: 20px 0;">Learn More</p>
                                </a>
                            </div>
                            <div class="Display-Card" data-tags="coh1,Strategy,Singleplayer,RTS">
                                <a href="">
                                    <img src="Assets/Img/Book 1.jpg">
                                    <p style="font-weight: bolder; text-transform: uppercase; padding: 20px 0 0;"> The First Consiparcy <br> <span style="color: rgb(100 100 100); font-weight: normal; text-transform: none; font-size: 14px;"> Brad Meltzer </span> </p>
                                    <p style="padding: 20px 0 0;"> Learn More </p>
                                </a>
                            </div>
                            <div class="Display-Card" data-tags="coh2,Strategy,Multiplayer,RTS">
                                <a href="">
                                    <img src="Assets/Img/Book 2.jpg">
                                    <p style="font-weight: bolder; text-transform: uppercase; padding: 20px 0 0;"> Benjamin Franklin <br> <span style="color: rgb(100 100 100); font-weight: normal; text-transform: none; font-size: 14px;"> Walter Isaacson </span> </p>
                                    <p style="padding: 20px 0 0;"> Learn More </p>
                                </a>
                            </div>
                            <div class="Display-Card" data-tags="coh3,Multiplayer">
                                <a href="">
                                    <img src="Assets/Img/Book 3.jpg">
                                    <p style="font-weight: bolder; text-transform: uppercase; padding: 20px 0 0;"> 1776 <br> <span style="color: rgb(100 100 100); font-weight: normal; text-transform: none; font-size: 14px;"> David McCullough </span> </p>
                                    <p style="padding: 20px 0 0;"> Learn More </p>
                                </a>
                            </div>
                            <div class="Display-Card" data-tags="coh1,Strategy,Singleplayer,RTS">
                                <a href="">
                                    <img src="Assets/Img/Book 4.jpg">
                                    <p style="font-weight: bolder; text-transform: uppercase; padding: 20px 0 0;"> History Of The United States <br> <span style="color: rgb(100 100 100); font-weight: normal; text-transform: none; font-size: 14px;"> Howard Zinn </span> </p>
                                    <p style="padding: 20px 0 0;"> Learn More </p>
                                </a>
                            </div>
                            <div class="Display-Card" data-tags="coh2,Strategy,Multiplayer,RTS">
                                <a href="">
                                    <img src="Assets/Img/Book 5.jpg">
                                    <p style="font-weight: bolder; text-transform: uppercase; padding: 20px 0 0;"> The Greatest Beer Run Ever <br> <span style="color: rgb(100 100 100); font-weight: normal; text-transform: none; font-size: 14px;"> John Dondhue </span> </p>
                                    <p style="padding: 20px 0 0;"> Learn More </p>
                                </a>
                            </div>
                            <div class="Display-Card" data-tags="coh3,Multiplayer">
                                <a href="">
                                    <img src="Assets/Img/Book 6.jpg">
                                    <p style="font-weight: bolder; text-transform: uppercase; padding: 20px 0 0;"> Black Flags, Blue Waters <br> <span style="color: rgb(100 100 100); font-weight: normal; text-transform: none; font-size: 14px;"> Eric Jay Dolin </span> </p>
                                    <p style="padding: 20px 0 0;"> Learn More </p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="modal" class="modal">
                <div class="modal-content">
                    <div class="modal-img">
                        <img id="modal-img" src="">
                    </div>
                    <div class="modal-info">
                        <h2 id="modal-title"></h2>
                        <p id="modal-author"></p>
                        <p style="width: 200px;" id="modal-desc"></p>
                        <button id="wishlist-button" onclick="addToWishlist()">Add to Wishlist</button>
                    </div>
                </div>
            </div>

            <div class="Footer">
                <div class="Footer-Container">
                    <div class="Nothingness-Logo">
                        <p> La Cité du Savoir/Home </p>
                    </div>
                    <div class="Container-Card">
                        <div class="Card-flex">
                            <div class="Card-flex-Blow">
                                <h1> Product </h1>
                                <div class="Text-Display">
                                    <p> Company Of Heroes </p>
                                    <p> Company Of Heroes 2 </p>
                                    <p> Company Of Heroes 3 </p>
                                </div>
                            </div>
                        </div>
                        <div class="Card-flex">
                            <div class="Card-flex-Blow">
                                <h1> Help </h1>
                                <div class="Text-Display">
                                    <p> Support </p>
                                    <p> Contact Us </p>
                                </div>
                            </div>
                        </div>
                        <div class="Card-flex">
                            <div class="Card-flex-Blow">
                                <h1> Community </h1>
                                <div class="Text-Display">
                                    <p> Discord </p>
                                    <p> Instagram </p>
                                    <p> Youtube </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--End Of Content-->

    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

    <script>
        function toggleMenu() {
            var navigationLinks = document.getElementById("navigationLinks");
            if (navigationLinks.classList.contains('active')) {
                navigationLinks.classList.remove('active');
            } else {
                navigationLinks.classList.add('active');
            }
        }
    
        window.addEventListener('scroll', function() {
            var navigationLinks = document.getElementById("navigationLinks");
            if (navigationLinks.classList.contains('active')) {
                navigationLinks.classList.add('scrolling');
            }
        });
    </script>

    <script>
        document.querySelectorAll('.Display-Card').forEach(card => {
            card.addEventListener('click', function(event) {
                event.preventDefault();
                const imgSrc = card.getAttribute('data-img');
                const bookTitle = card.getAttribute('data-title');
                const author = card.getAttribute('data-author');
                const desc = card.getAttribute('data-desc');

                document.getElementById('modal-img').src = imgSrc;
                document.getElementById('modal-title').innerText = bookTitle;
                document.getElementById('modal-author').innerText = author;
                document.getElementById('modal-desc').innerText = desc;

                document.getElementById('modal').style.display = 'block';
            });
        });

        window.addEventListener('click', function(event) {
            if (event.target == document.getElementById('modal')) {
                document.getElementById('modal').style.display = 'none';
            }
        });
    </script>

    <script>
        function addToWishlist() {
            const title = document.getElementById('modal-title').innerText;
            const author = document.getElementById('modal-author').innerText;
            const imgSrc = document.getElementById('modal-img').src;
            const description = document.getElementById('modal-desc').innerText;

            console.log("Sending data:", { title, author, imgSrc, description });

            const data = new FormData();
            data.append('title', title);
            data.append('author', author);
            data.append('imgSrc', imgSrc);
            data.append('description', description);

            fetch('add_to_wishlist.php', {
                method: 'POST',
                body: data
            })
            .then(response => response.text())
            .then(result => {
                console.log('Server response:', result);
                alert('Added to wishlist!');
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to add to wishlist');
            });
        }
    </script>

</body>
</html>