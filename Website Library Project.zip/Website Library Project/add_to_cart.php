<?php
include 'config.php'; // Sesuaikan dengan nama file konfigurasi Anda

// Ambil data dari request POST
$data = json_decode(file_get_contents("php://input"));

if (!empty($data->id)) {
    $id = $data->id;

    // Ambil data dari tabel wishlist berdasarkan ID
    $sql = "SELECT * FROM wishlist WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Simpan data ke tabel cart
        $title = $row['title'];
        $author = $row['author'];
        $img = $row['img'];

        $insertSql = "INSERT INTO cart (title, author, img) VALUES ('$title', '$author', '$img')";
        if ($conn->query($insertSql) === TRUE) {
            echo "Item added to cart successfully";
        } else {
            echo "Error: " . $insertSql . "<br>" . $conn->error;
        }
    } else {
        echo "No item found with ID: $id";
    }
} else {
    echo "Invalid data received";
}

$conn->close();
?>
