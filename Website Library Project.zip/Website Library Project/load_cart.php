<?php
include 'config.php'; // Sesuaikan dengan nama file konfigurasi Anda

// Query untuk mengambil semua data dari tabel cart
$sql = "SELECT * FROM cart";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Tampilkan data sebagai list
    echo "<h2>Cart Items:</h2>";
    echo "<ul>";
    while ($row = $result->fetch_assoc()) {
        echo "<li>";
        echo "<strong>Title:</strong> " . $row['title'] . "<br>";
        echo "<strong>Author:</strong> " . $row['author'] . "<br>";
        echo "<img src='" . $row['img'] . "' alt='Book Image'><br>";
        echo "</li>";
    }
    echo "</ul>";
} else {
    echo "No items in cart.";
}

$conn->close();
?>
