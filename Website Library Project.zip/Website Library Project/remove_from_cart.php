<?php
// Ambil data yang dikirimkan dari JavaScript
$data = json_decode(file_get_contents("php://input"));

// Simpan data ke dalam variabel
$id = $data->id;

// Koneksi ke database
$servername = "localhost"; // Ganti sesuai dengan server Anda
$username = "root"; // Ganti dengan username PHPMyAdmin Anda
$password = ""; // Ganti dengan password PHPMyAdmin Anda
$dbname = "bookstore"; // Ganti dengan nama database Anda

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query untuk menghapus data dari tabel cart berdasarkan ID
$sql = "DELETE FROM cart WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "Item removed from cart successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>
