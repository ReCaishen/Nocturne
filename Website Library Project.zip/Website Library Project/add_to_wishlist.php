<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bookstore";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from POST request
$bookTitle = $_POST['title'] ?? '';
$author = $_POST['author'] ?? '';
$imgSrc = $_POST['imgSrc'] ?? '';
$description = $_POST['description'] ?? '';

// Log received data
error_log("Received data: " . print_r($_POST, true));

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO wishlist (user_id, book_title, author, img_src, description) VALUES (?, ?, ?, ?, ?)");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("issss", $userId, $bookTitle, $author, $imgSrc, $description);

// Set parameters and execute
$userId = 1; // This should be the actual user ID when you implement user accounts
if ($stmt->execute()) {
    echo "New record created successfully";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>